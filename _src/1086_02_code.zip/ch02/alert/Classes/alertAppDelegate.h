//
//  alertAppDelegate.h
//  alert
//
//  Created by Arturo on 11/1/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface alertAppDelegate : PhoneGapDelegate {
}

@end

