//
//  play_phonegapAppDelegate.h
//  play_phonegap
//
//  Created by Arturo on 12/9/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface play_phonegapAppDelegate : PhoneGapDelegate {
}

@end

