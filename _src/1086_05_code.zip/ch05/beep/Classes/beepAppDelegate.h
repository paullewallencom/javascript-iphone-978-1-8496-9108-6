//
//  beepAppDelegate.h
//  beep
//
//  Created by Arturo on 12/7/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface beepAppDelegate : PhoneGapDelegate {
}

@end

