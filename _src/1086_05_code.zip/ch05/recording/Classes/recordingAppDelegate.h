//
//  recordingAppDelegate.h
//  recording
//
//  Created by Arturo on 12/9/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface recordingAppDelegate : PhoneGapDelegate {
}

@end

