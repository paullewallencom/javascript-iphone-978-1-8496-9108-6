//
//  newContactAppDelegate.h
//  newContact
//
//  Created by Arturo on 1/27/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface newContactAppDelegate : PhoneGapDelegate {
}

@end

