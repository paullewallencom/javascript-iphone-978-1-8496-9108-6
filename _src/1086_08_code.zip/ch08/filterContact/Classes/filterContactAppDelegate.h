//
//  filterContactAppDelegate.h
//  filterContact
//
//  Created by Arturo on 1/28/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface filterContactAppDelegate : PhoneGapDelegate {
}

@end

